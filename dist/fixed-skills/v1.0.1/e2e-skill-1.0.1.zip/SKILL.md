---
name: e2e
description: 安装、升级、启动和管理本机E2E 工作台（Windows x64 / macOS Apple Silicon）。
---

# E2E 工作台

此 Skill 为固定提交版本 v1.0.1。Skill 包只包含启动和安装引导；Python、依赖、浏览器、编译核心及运行时 Launcher 均来自 GitHub 已发布的对应平台完整 Runtime。**不使用固定的业务程序版本**：每次 `install`/`update` 从 `BrianOGG/ISV-Release` 的 Releases 中获取最新、非 draft 且包含匹配平台 tar.gz 和 SHA256 digest 的便携 Runtime。

## 使用方式

先执行 `prepare` 检查平台，再执行 `install`，随后 `start`。首次安装需要联网；仅安装/显式更新时检查云端最新版本；日常启动使用本地已验证版本，不会自动覆盖正在运行的任务。更新前先执行 `stop`；安装失败保留旧版本。

macOS Apple Silicon：`sh "<skill-dir>/scripts/setup.sh" prepare`、`install`、`start`；也支持 `update`、`status`、`stop`、`doctor`、`version`，`--port` 和 `--install-dir`。

Windows x64：`powershell -NoProfile -ExecutionPolicy Bypass -File "<skill-dir>\scripts\setup.ps1" -Action prepare`，将 `prepare` 改为 `install`、`start`、`update`、`status`、`stop`、`doctor` 或 `version`；可用 `-Port`、`-InstallDir` 参数。

工作台默认端口 `8787`。启动成功后告知用户服务地址。业务登录、验证码、账号及任务操作在工作台中进行，勿自动重复提交任务。遇到下载安装失败，返回错误码，不要循环安装。

不需要安装系统 Python、pip 或自行编译；安装会联网下载完整包并按 Release 资产的 SHA256 值验证，失败不会切换当前版本。若云端尚无通过验收的对应平台 Release，提示 `PORTABLE_RELEASE_UNAVAILABLE`，待新 Release 发布后原 Skill 可以直接再次安装，无需重新导入。
