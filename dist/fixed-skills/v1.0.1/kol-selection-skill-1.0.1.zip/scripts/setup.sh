#!/bin/sh
# Immutable Skill bootstrap: the actual Python, browser, launcher and compiled Core are downloaded at install/update.
set -eu
umask 077
PROJECT='kol-selection'
APPDIR='KOLSelection'
PORT='8788'
[ "$(uname -s)" = Darwin ] && [ "$(uname -m)" = arm64 ] || { echo PORTABLE_UNSUPPORTED_PLATFORM >&2; exit 1; }
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
ACTION=${1:-prepare}
if [ "$#" -gt 0 ]; then shift; fi
ROOT="$HOME/Applications/$APPDIR"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --install-dir) [ "$#" -gt 1 ] || exit 2; ROOT=$2; shift 2 ;;
    --port) [ "$#" -gt 1 ] || exit 2; PORT=$2; shift 2 ;;
    *) echo PORTABLE_INVALID_ARGUMENT >&2; exit 2 ;;
  esac
done
case "$ACTION" in prepare|install|update|start|status|stop|doctor|version) ;; *) echo PORTABLE_INVALID_ACTION >&2; exit 2;; esac
if [ "$ACTION" = prepare ]; then
  for command in curl shasum tar osascript; do command -v "$command" >/dev/null || { echo PORTABLE_SYSTEM_TOOLS_MISSING >&2; exit 1; }; done
  echo "PORTABLE_READY project=$PROJECT platform=macos-arm64"; exit 0
fi
CACHE="$ROOT/portable"
POINTER="$CACHE/current"
JSON_HELPER="$SCRIPT_DIR/resolve-macos.js"
if [ "$ACTION" = install ] || [ "$ACTION" = update ]; then
  mkdir -p "$CACHE"
  RESOLVED="$CACHE/.releases.$$"
  RELEASES="$CACHE/.github-releases.$$"
  trap 'rm -f "$RELEASES" "$RESOLVED"' EXIT HUP INT TERM
  curl --fail --silent --show-error --location --retry 3 --connect-timeout 30 \
    --header 'Accept: application/vnd.github+json' --header 'User-Agent: ECAI-Immutable-Skill/1.0' \
    'https://api.github.com/repos/BrianOGG/ISV-Release/releases?per_page=100' --output "$RELEASES" ||
    { echo PORTABLE_RELEASE_LOOKUP_FAILED >&2; exit 1; }
  osascript -l JavaScript "$JSON_HELPER" releases "$RELEASES" "$PROJECT" > "$RESOLVED" ||
    { echo PORTABLE_RELEASE_UNAVAILABLE >&2; exit 1; }
  VERSION=$(sed -n '1p' "$RESOLVED")
  URL=$(sed -n '2p' "$RESOLVED")
  HASH=$(sed -n '3p' "$RESOLVED")
  rm -f "$RELEASES" "$RESOLVED"
  case "$HASH" in *[!a-f0-9]*|'') echo PORTABLE_INVALID_SHA256 >&2; exit 1;; esac
  [ "${#HASH}" -eq 64 ] || { echo PORTABLE_INVALID_SHA256 >&2; exit 1; }
  ARCHIVE="$CACHE/$HASH.tar.gz"
  BUNDLE="$CACHE/$HASH"
  if [ ! -f "$BUNDLE/portable.json" ]; then
    if [ ! -f "$ARCHIVE" ] || [ "$(shasum -a 256 "$ARCHIVE" | cut -d ' ' -f 1)" != "$HASH" ]; then
      rm -f "$ARCHIVE.part"
      curl --fail --location --retry 3 --connect-timeout 30 "$URL" --output "$ARCHIVE.part" ||
        { echo PORTABLE_DOWNLOAD_FAILED >&2; exit 1; }
      [ "$(shasum -a 256 "$ARCHIVE.part" | cut -d ' ' -f 1)" = "$HASH" ] ||
        { rm -f "$ARCHIVE.part"; echo PORTABLE_HASH_MISMATCH >&2; exit 1; }
      mv "$ARCHIVE.part" "$ARCHIVE"
    fi
    STAGE=$(mktemp -d "$CACHE/.stage.XXXXXXXX")
    trap 'rm -rf "$STAGE"' EXIT HUP INT TERM
    tar -xzf "$ARCHIVE" -C "$STAGE" || { echo PORTABLE_EXTRACTION_FAILED >&2; exit 1; }
    [ -f "$STAGE/portable.json" ] && [ -f "$STAGE/ecai_launcher.py" ] ||
      { echo PORTABLE_RUNTIME_INCOMPLETE >&2; exit 1; }
    osascript -l JavaScript "$JSON_HELPER" metadata "$STAGE/portable.json" "$PROJECT" >/dev/null ||
      { echo PORTABLE_METADATA_MISMATCH >&2; exit 1; }
    mv "$STAGE" "$BUNDLE"
    trap - EXIT HUP INT TERM
  fi
else
  [ -f "$POINTER" ] || { echo PORTABLE_NOT_INSTALLED >&2; exit 1; }
  HASH=$(sed -n '1p' "$POINTER")
  VERSION=$(sed -n '2p' "$POINTER")
  case "$HASH" in *[!a-f0-9]*|'') echo PORTABLE_INVALID_LOCAL_POINTER >&2; exit 1;; esac
  [ "${#HASH}" -eq 64 ] || { echo PORTABLE_INVALID_LOCAL_POINTER >&2; exit 1; }
  BUNDLE="$CACHE/$HASH"
fi
[ -f "$BUNDLE/portable.json" ] && [ -f "$BUNDLE/ecai_launcher.py" ] ||
  { echo PORTABLE_RUNTIME_INCOMPLETE >&2; exit 1; }
META=$(osascript -l JavaScript "$JSON_HELPER" metadata "$BUNDLE/portable.json" "$PROJECT") ||
  { echo PORTABLE_METADATA_MISMATCH >&2; exit 1; }
ACTUAL_VERSION=$(printf '%s\n' "$META" | sed -n '1p')
PY_REL=$(printf '%s\n' "$META" | sed -n '2p')
[ "$ACTUAL_VERSION" = "$VERSION" ] || { echo PORTABLE_VERSION_MISMATCH >&2; exit 1; }
BASE_PYTHON="$BUNDLE/$PY_REL"
[ -f "$BASE_PYTHON" ] || { echo PORTABLE_PYTHON_MISSING >&2; exit 1; }
PYTHON="$BUNDLE/venv/bin/python"
if [ ! -f "$PYTHON" ]; then
  "$BASE_PYTHON" -I -m venv --without-pip --system-site-packages "$BUNDLE/venv" ||
    { echo PORTABLE_VENV_BOOTSTRAP_FAILED >&2; exit 1; }
fi
export ECAI_PORTABLE_ROOT="$BUNDLE"
if [ "$PROJECT" = kol-selection ]; then export PLAYWRIGHT_BROWSERS_PATH="$BUNDLE/browsers"; fi
if [ "$PROJECT" = e2e ]; then
  BROWSER_REL=$(printf '%s\n' "$META" | sed -n '3p')
  export E2E_CHROME_PATH="$BUNDLE/$BROWSER_REL"
fi
if [ "$ACTION" = install ] || [ "$ACTION" = update ]; then
  RESULT=$("$PYTHON" -I "$BUNDLE/ecai_launcher.py" --release "$BUNDLE/release" version) ||
    { echo PORTABLE_CORE_IMPORT_FAILED >&2; exit 1; }
  [ "$RESULT" = "$VERSION" ] || { echo PORTABLE_CORE_VERSION_MISMATCH >&2; exit 1; }
  "$PYTHON" -I "$BUNDLE/ecai_launcher.py" --release "$BUNDLE/release" doctor ||
    { echo PORTABLE_BROWSER_CHECK_FAILED >&2; exit 1; }
  printf '%s\n%s\n' "$HASH" "$VERSION" > "$POINTER.new"
  mv "$POINTER.new" "$POINTER"
  echo "PORTABLE_INSTALLED project=$PROJECT version=$VERSION"
  exit 0
fi
exec "$PYTHON" -I "$BUNDLE/ecai_launcher.py" --release "$BUNDLE/release" "$ACTION" --port "$PORT"
