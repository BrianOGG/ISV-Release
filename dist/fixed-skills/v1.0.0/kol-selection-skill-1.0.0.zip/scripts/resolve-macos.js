/* Bundled, immutable GitHub Release resolver for macOS (JXA/osascript). */
ObjC.import('Foundation');
function readJSON(path) {
  var value = $.NSString.stringWithContentsOfFileEncodingError($(path), $.NSUTF8StringEncoding, null);
  if (!value) throw new Error('PORTABLE_JSON_READ_FAILED');
  return JSON.parse(ObjC.unwrap(value));
}
function run(argv) {
  var mode=argv[0], path=argv[1], project=argv[2];
  if (!/^(kol-selection|e2e)$/.test(project)) throw new Error('PORTABLE_INVALID_PROJECT');
  if (mode === 'metadata') {
    var m=readJSON(path);
    if (m.project !== project || m.platform !== 'macos-arm64' || m.packages_preinstalled !== true)
      throw new Error('PORTABLE_METADATA_MISMATCH');
    var py=m.python_executable;
    if (!/^python\/[A-Za-z0-9/._-]+$/.test(py) || py.indexOf('..') !== -1)
      throw new Error('PORTABLE_INVALID_PYTHON_PATH');
    return [m.version, py].join('\n');
  }
  if (mode !== 'releases') throw new Error('PORTABLE_INVALID_MODE');
  var list=readJSON(path), prefix=project+'-portable-mac-', candidates=[];
  if (!Array.isArray(list)) throw new Error('PORTABLE_INVALID_RELEASE_LIST');
  list.forEach(function(rel) {
    if (rel.draft || !rel.tag_name || rel.tag_name.indexOf(prefix)!==0) return;
    var version=rel.tag_name.substring(prefix.length);
    if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/.test(version)) return;
    var name=project+'-portable-macos-arm64-'+version+'.tar.gz';
    var url='https://github.com/BrianOGG/ISV-Release/releases/download/'+rel.tag_name+'/'+name;
    (rel.assets||[]).forEach(function(a) {
      if (a.name===name && a.browser_download_url===url && a.state==='uploaded' &&
          /^sha256:[0-9a-f]{64}$/.test(a.digest||''))
        candidates.push({version:version,url:url,hash:a.digest.substring(7),date:Date.parse(rel.published_at||'')||0});
    });
  });
  candidates.sort(function(a,b){return b.date-a.date;});
  if (!candidates.length) throw new Error('PORTABLE_RELEASE_UNAVAILABLE');
  var s=candidates[0];
  return [s.version,s.url,s.hash].join('\n');
}
