﻿# Immutable Skill bootstrap (Windows PowerShell 5.1+). Runtime code comes from GitHub Releases.
param(
  [ValidateSet('prepare','install','update','start','status','stop','doctor','version')][string]$Action='prepare',
  [string]$InstallDir='',
  [int]$Port=0
)
$ErrorActionPreference='Stop'
$Project='kol-selection'
$DefaultPort=8788
function Fail([string]$Code) { throw $Code }
try {
  if ($env:OS -ne 'Windows_NT' -or -not [Environment]::Is64BitOperatingSystem) { Fail 'PORTABLE_UNSUPPORTED_PLATFORM' }
  if ($Port -eq 0) { $Port=$DefaultPort }
  if (-not $InstallDir) { $InstallDir=Join-Path $env:LOCALAPPDATA 'Programs/KOLSelection' }
  if ($Action -eq 'prepare') { Write-Output "PORTABLE_READY project=$Project platform=windows-x64"; exit 0 }
  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
  $Cache=Join-Path $InstallDir 'portable'
  $Pointer=Join-Path $Cache 'current.json'
  $Platform='windows-x64'
  if ($Action -eq 'install' -or $Action -eq 'update') {
    $Releases=@(Invoke-RestMethod -Uri 'https://api.github.com/repos/BrianOGG/ISV-Release/releases?per_page=100' -Headers @{ 'User-Agent'='ECAI-Immutable-Skill/1.0';'Accept'='application/vnd.github+json' } -UseBasicParsing)
    $Prefix="$Project-portable-win-"
    $Candidates=@()
    foreach ($Release in $Releases) {
      if ($Release.draft -or -not $Release.tag_name.StartsWith($Prefix,[StringComparison]::Ordinal)) { continue }
      $Version=$Release.tag_name.Substring($Prefix.Length)
      if ($Version -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$') { continue }
      $ArchiveName="$Project-portable-windows-x64-$Version.tar.gz"
      $Expected="https://github.com/BrianOGG/ISV-Release/releases/download/$($Release.tag_name)/$ArchiveName"
      $Asset=@($Release.assets | Where-Object { $_.name -ceq $ArchiveName -and $_.browser_download_url -ceq $Expected -and $_.state -eq 'uploaded' -and $_.digest -match '^sha256:[0-9a-f]{64}$' }) | Select-Object -First 1
      if ($Asset) {
        $Candidates+= [pscustomobject]@{ Version=$Version; Hash=$Asset.digest.Substring(7); Url=$Expected; PublishedAt=$Release.published_at }
      }
    }
    $Selected=$Candidates | Sort-Object PublishedAt -Descending | Select-Object -First 1
    if (-not $Selected) { Fail 'PORTABLE_RELEASE_UNAVAILABLE' }
    New-Item -ItemType Directory -Force -Path $Cache | Out-Null
    $Hash=$Selected.Hash
    $Archive=Join-Path $Cache ($Hash+'.tar.gz')
    $Bundle=Join-Path $Cache $Hash
    if (-not (Test-Path -LiteralPath (Join-Path $Bundle 'portable.json'))) {
      if (-not (Test-Path -LiteralPath $Archive) -or (Get-FileHash -Algorithm SHA256 -LiteralPath $Archive).Hash.ToLowerInvariant() -ne $Hash) {
        $Part=$Archive+'.part'
        try {
          Invoke-WebRequest -Uri $Selected.Url -OutFile $Part -UseBasicParsing
          if ((Get-FileHash -Algorithm SHA256 -LiteralPath $Part).Hash.ToLowerInvariant() -ne $Hash) { Fail 'PORTABLE_HASH_MISMATCH' }
          Move-Item -LiteralPath $Part -Destination $Archive -Force
        } finally { if (Test-Path -LiteralPath $Part) { Remove-Item -LiteralPath $Part -Force } }
      }
      $Stage=Join-Path $Cache ('.stage.'+[guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Force -Path $Stage | Out-Null
      try {
        & tar.exe -xzf $Archive -C $Stage
        if ($LASTEXITCODE -ne 0) { Fail 'PORTABLE_EXTRACTION_FAILED' }
        $MetaPath=Join-Path $Stage 'portable.json'
        if (-not (Test-Path -LiteralPath $MetaPath)) { Fail 'PORTABLE_METADATA_MISSING' }
        $Meta=Get-Content -LiteralPath $MetaPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($Meta.project -cne $Project -or $Meta.platform -cne $Platform -or $Meta.version -cne $Selected.Version -or $Meta.packages_preinstalled -ne $true) { Fail 'PORTABLE_METADATA_MISMATCH' }
        if (-not (Test-Path -LiteralPath (Join-Path $Stage 'ecai_launcher.py'))) { Fail 'PORTABLE_LAUNCHER_MISSING' }
        Move-Item -LiteralPath $Stage -Destination $Bundle
      } finally { if (Test-Path -LiteralPath $Stage) { Remove-Item -LiteralPath $Stage -Recurse -Force } }
    }
  } else {
    if (-not (Test-Path -LiteralPath $Pointer)) { Fail 'PORTABLE_NOT_INSTALLED' }
    $Selected=Get-Content -LiteralPath $Pointer -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($Selected.Hash -notmatch '^[0-9a-f]{64}$' -or $Selected.Version -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$') { Fail 'PORTABLE_INVALID_LOCAL_POINTER' }
    $Hash=$Selected.Hash
    $Bundle=Join-Path $Cache $Hash
    if (-not (Test-Path -LiteralPath (Join-Path $Bundle 'portable.json'))) { Fail 'PORTABLE_NOT_INSTALLED' }
  }
  $Meta=Get-Content -LiteralPath (Join-Path $Bundle 'portable.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($Meta.project -cne $Project -or $Meta.platform -cne $Platform -or $Meta.version -cne $Selected.Version -or $Meta.packages_preinstalled -ne $true) { Fail 'PORTABLE_METADATA_MISMATCH' }
  $Exe=$Meta.python_executable
  if ($Exe -notmatch '^python/[a-zA-Z0-9/._-]+\.exe$' -or $Exe -match '\.\.') { Fail 'PORTABLE_INVALID_PYTHON_PATH' }
  $BasePython=Join-Path $Bundle ($Exe -replace '/', '\')
  if (-not (Test-Path -LiteralPath $BasePython)) { Fail 'PORTABLE_PYTHON_MISSING' }
  $Python=Join-Path $Bundle 'venv/Scripts/python.exe'
  if (-not (Test-Path -LiteralPath $Python)) {
    & $BasePython -I -m venv --without-pip --system-site-packages (Join-Path $Bundle 'venv')
    if ($LASTEXITCODE -ne 0) { Fail 'PORTABLE_VENV_BOOTSTRAP_FAILED' }
  }
  $env:ECAI_PORTABLE_ROOT=$Bundle
  if ($Project -eq 'kol-selection') { $env:PLAYWRIGHT_BROWSERS_PATH=Join-Path $Bundle 'browsers' }
  else { $env:E2E_CHROME_PATH=Join-Path $Bundle 'browser/chrome-win64/chrome.exe' }
  $Launcher=Join-Path $Bundle 'ecai_launcher.py'
  if (-not (Test-Path -LiteralPath $Launcher)) { Fail 'PORTABLE_LAUNCHER_MISSING' }
  $ReleaseDir=Join-Path $Bundle 'release'
  if ($Action -eq 'install' -or $Action -eq 'update') {
    $Actual=(& $Python -I $Launcher --release $ReleaseDir version | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $Actual -cne $Selected.Version) { Fail 'PORTABLE_CORE_IMPORT_FAILED' }
    & $Python -I $Launcher --release $ReleaseDir doctor
    if ($LASTEXITCODE -ne 0) { Fail 'PORTABLE_BROWSER_CHECK_FAILED' }
    $PointerNew=$Pointer+'.new'
    [IO.File]::WriteAllText($PointerNew,($Selected | ConvertTo-Json -Compress),[Text.Encoding]::UTF8)
    Move-Item -LiteralPath $PointerNew -Destination $Pointer -Force
    Write-Output "PORTABLE_INSTALLED project=$Project version=$($Selected.Version)"
    exit 0
  }
  & $Python -I $Launcher --release $ReleaseDir $Action --port $Port
  exit $LASTEXITCODE
} catch {
  if ($_.Exception.Message -match '^PORTABLE_[A-Z_]+$') { [Console]::Error.WriteLine($_.Exception.Message) }
  else { [Console]::Error.WriteLine('PORTABLE_OPERATION_FAILED') }
  exit 1
}
